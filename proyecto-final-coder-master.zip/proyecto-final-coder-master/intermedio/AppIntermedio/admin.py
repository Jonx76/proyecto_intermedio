from django.contrib import admin
from .models import Libro

# Register your models here.
admin.site.register(Libro)

